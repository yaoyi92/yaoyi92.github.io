#####
GMX=gmx
VMD=vmd
#####
ln -s ../1.1-initial_structures_gromacs/water55.gro .
ln -s ../1.2-initial_structures_lammps/water55.psf .  # for symbols we use this psf file
gmx grompp -f min.mdp -c water55.gro -p water55.top -o min.tpr
gmx mdrun -s min.tpr -c em.gro
gmx grompp -f nvt.mdp -c em.gro -p water55.top -o nvt.tpr
gmx mdrun -s nvt.tpr
gmx trjconv -s nvt.tpr -f traj_comp.xtc -o traj_comp_whole.xtc -pbc whole <<< "0"
vmd -dispdev none -e take_last_snapshot.vmd
