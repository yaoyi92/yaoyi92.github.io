from mdsystem import *
f = file("water55.xyz")
s = mdsystem(cell = [11.8172, 11.8172, 11.8172])
s.xyzinput(f)
s.generate_bonds(cutoff = 1.2)
s.molecular_detection()
for i in range(len(s.moleculars)):
    s.molecular_names.append("SOL")
print s.grooutput()
