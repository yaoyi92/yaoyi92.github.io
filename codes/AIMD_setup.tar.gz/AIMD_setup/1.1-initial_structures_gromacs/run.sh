##### modify these lines
PACKMOL=~/software/packmol/packmol/packmol
VMD=vmd
#####
$PACKMOL < water55_packmol.in > water55_packmol.out
python convert_xyz_to_gro.py > water55.gro
vmd -dispdev none -e convert.vmd
