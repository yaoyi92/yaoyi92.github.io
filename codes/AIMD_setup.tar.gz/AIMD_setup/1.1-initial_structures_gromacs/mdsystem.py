
"""
I write this python class to manipulate the MD simulation structure
for CPV in quantum-espresso.
The system is in periodic boundary condition. Only support orthogonal cells.

two classes
atom
mdsystem

YIY
2012-12-31

Add molecular detection

modified
YIY
2013-01-02

Add dipole moment calculation

modified
YIY
2013-01-04

Add groinput

modified
YIY
2013-01-10

Add mdsystem.molecule_names.
YIY
2013-01-11
"""

import math
import numpy as np
from scipy import linalg as LA


class atom:
    """
    A class to represent an atom.
    """
    def __init__(self, index, species, coordinates = [0.0, 0.0, 0.0]):
        self.index = index
        self.species = species
        self.coordinates = np.array(coordinates)
        
    def __repr__(self):
        string = "index: " + str(self.index) + " species: " + self.species + \
                 " coordinates: " + str(self.coordinates) + "\n"
        return string
    
    def __str__(self):
        string = "index: " + str(self.index) + " species: " + self.species + \
                 " coordinates: " + str(self.coordinates) + " \n"
        return string


class mdsystem:
    """
    A class to represent a snapshot the whole system.
    """
    def __init__(self, atoms = [], bonds = [], cell = []):
        self.atoms = atoms
        self.bonds = bonds
        self.cell = np.array(cell)
        self.moleculars = []
        self.molecular_names = []
        self.trajectory = [] # the trajectory of the whole system in the order of atoms
        
    def __repr__(self):
        string = "atoms: \n" + str(self.atoms) + "\nbonds: \n" + str(self.bonds) + \
                 "\ncell: \n" + str(self.cell)  +"\nmoleculars: \n" + \
                 str(self.moleculars) + "\n" + "molecular_names \n" + \
                 str(self.molecular_names) +"\n"
        return string
    
    def __str__(self):
        string = "atoms: \n" + str(self.atoms) + "\nbonds: \n" + str(self.bonds) + \
                 "\ncell: \n" + str(self.cell) +"\nmoleculars: \n" + \
                 str(self.moleculars) + "\n"+ "molecular_names \n" + \
                 str(self.molecular_names) +"\n"
        return string
    
    def __getitem__(self, index):
        return self.atoms[index] 

    def xyzinput(self, xyzfile):
        """
        input a new xyz file
        """
        xyz = ""
        xyz += xyzfile.readline()
        natom = int(xyz.split()[0])
        xyz += xyzfile.readline()
        for i in range(natom):
            xyz += xyzfile.readline()
        self.atoms = []
        self.bonds = []
        lines = xyz.split("\n")
        natom = int(lines[0])
        for n in range(natom):
            line = lines[n+2]
            words = line.split()
            species = words[0]
            coordinate_x = float(words[1])
            coordinate_y = float(words[2])
            coordinate_z = float(words[3])
            coordinate = [coordinate_x, coordinate_y, coordinate_z]
            self.atoms.append(atom(n, species, coordinate))
        return True

    def groinput(self, grofile):
        """
        input a new gro file
        """
        gro = ""
        grofile.readline()
        gro += grofile.readline()
        natom = int(gro.split()[0])
        for i in range(natom):
            gro += grofile.readline()
        self.atoms = []
        self.bonds = []
        lines = gro.split("\n")
        natom = int(lines[0])
        nmolecule = 0
        molecular = []
        for n in range(natom):
            line = lines[n+1]
            words = line.split()
            species = line[10:15]

            coordinate_x = float(line[20:28])
            coordinate_y = float(line[28:36])
            coordinate_z = float(line[36:44])
            coordinate = [coordinate_x, coordinate_y, coordinate_z]
            self.atoms.append(atom(n, species, coordinate))
            if int(line[0:5]) == nmolecule:
                molecular.append(n)
            if int(line[0:5]) != nmolecule:
                if len(molecular)>0:
                    self.moleculars.append(molecular)
                nmolecule += 1
                self.molecular_names.append(line[5:10])
                molecular = [n,]
            if n == natom - 1:
                self.moleculars.append(molecular)
        gro = grofile.readline()
        cell = gro.split()
        self.cell = [float(cell[0]), float(cell[1]), float(cell[2])]
        return True

    def xyzupdate(self, xyzfile):
        """
        get the next structure snapshot in the xyz file
        """
        xyz = ""
        xyz += xyzfile.readline()
        if len(xyz) == 0:
            print "reach the end of the file"
            xyzfile.close()
            return False
        natom = int(xyz.split()[0])
        xyz += xyzfile.readline()
        for i in range(natom):
            xyz += xyzfile.readline()
        lines = xyz.split("\n")
        natom = int(lines[0])
        for n in range(natom):
            line = lines[n+2]
            words = line.split()
            coordinate_x = float(words[1])
            coordinate_y = float(words[2])
            coordinate_z = float(words[3])
            coordinate = [coordinate_x, coordinate_y, coordinate_z]
            self.atoms[n].coordinates = np.array(coordinate)
        
        return True

    def xyztrj_input(self, xyzfile):
        """
        load the whole trajectory of an xyzfile
        """
        while True:
            xyz = ""
            xyz += xyzfile.readline()
            if len(xyz) == 0:
                print "reach the end of the file"
                xyzfile.close()
                return False
            natom = int(xyz.split()[0])
            xyz += xyzfile.readline()
            for i in range(natom):
                xyz += xyzfile.readline()
            lines = xyz.split("\n")
            natom = int(lines[0])
            coordinates = []
            for n in range(natom):
                line = lines[n+2]
                words = line.split()
                coordinate_x = float(words[1])
                coordinate_y = float(words[2])
                coordinate_z = float(words[3])
                coordinate = [coordinate_x, coordinate_y, coordinate_z]
                coordinates.append(coordinate)
            self.trajectory.append(coordinates)
        
        return True
        

    def groupdate(self, grofile):
        """
        get the next structure snapshot in the gro file
        """
        gro = ""
        gro = grofile.readline()
        if len(gro) == 0:
            print "reach the end of the file"
            grofile.close()
            return False
        gro = grofile.readline()
        natom = int(gro.split()[0])
        for i in range(natom):
            gro += grofile.readline()
        lines = gro.split("\n")
        natom = int(lines[0])
        for n in range(natom):
            line = lines[n+1]
            words = line.split()
            coordinate_x = float(words[3])
            coordinate_y = float(words[4])
            coordinate_z = float(words[5])
            coordinate = [coordinate_x, coordinate_y, coordinate_z]
            self.atoms[n].coordinates = np.array(coordinate)
        gro = grofile.readline()
        cell = gro.split()
        self.cell = [float(cell[0]), float(cell[1]), float(cell[2])]
        return True
    
    def xyzoutput(self):
        """
        output the xyz of the mdsystem in a string (one snapshot).
        """
        string = str(len(self.atoms)) + "\n\n"
        for atom in self.atoms:
            string += "%3s  %8.6f  %8.6f  %8.6f\n" %( atom.species, atom.coordinates[0], atom.coordinates[1], atom.coordinates[2])     
        return string[:-1]

    def grooutput(self):
        """
        output the gro of the mdsystem in a string (one snapshot).
        """
        string = "generate by YIY" + "\n"
        string += str(len(self.atoms)) + "\n"
        n_molecular = 0
        n_atom = 0
        for molecular in self.moleculars:
            n_molecular += 1
            for atomindex in molecular:
                n_atom += 1
                atom = self.atoms[atomindex]
                string +="%5d%-5s%5s%5d%8.3f%8.3f%8.3f\n" % ( n_molecular , self.molecular_names[n_molecular-1], \
                                                                           atom.species, n_atom, atom.coordinates[0]/10, \
                                                                           atom.coordinates[1]/10, atom.coordinates[2]/10 )
        string += "%10.5f%10.5f%10.5f" % (self.cell[0]/10, self.cell[1]/10, self.cell[2]/10)
        return string
    
    def generate_bonds(self, cutoff = 2.2):
        self.bonds = []
        for atom1 in self.atoms:
            #print atom1.index
            for atom2 in self.atoms:
                distance = self.calculate_length(atom1, atom2)
                if ((atom1.index != atom2.index) and ( distance < cutoff) and (atom1.index < atom2.index)):
                    self.bonds.append([atom1.index, atom2.index])

    def calculate_length(self, atom1, atom2, incell = False):
        if isinstance(atom1, int):
            atom1 = self.atoms[atom1]
        if isinstance(atom2, int):
            atom2 = self.atoms[atom2]
        vector = atom2.coordinates - atom1.coordinates
        if incell == True:
            vector = self.incell3d(vector, self.cell)
        distance = LA.norm(vector)
        return distance
    
    def calculate_angle(self, atom1, atom2, atom3, incell = False):
        if isinstance(atom1, int):
            atom1 = self.atoms[atom1]
        if isinstance(atom2, int):
            atom2 = self.atoms[atom2]
        if isinstance(atom3, int):
            atom3 = self.atoms[atom3]
        vector1 = atom1.coordinates - atom2.coordinates
        vector2 = atom3.coordinates - atom2.coordinates
        if incell == True:
            vector1 = self.incell3d(vector1, self.cell)
            vector2 = self.incell3d(vector2, self.cell)
        distance1 = LA.norm(vector1)
        distance2 = LA.norm(vector2)
        inner = np.dot(vector1, vector2)
        angle = np.arccos(inner / (distance1 * distance2)) / (np.pi) * 180
        return angle

    def calculate_dihedral(self, atom1, atom2, atom3, atom4, incell = False):
        if isinstance(atom1, int):
            atom1 = self.atoms[atom1]
        if isinstance(atom2, int):
            atom2 = self.atoms[atom2]
        if isinstance(atom3, int):
            atom3 = self.atoms[atom3]
        if isinstance(atom4, int):
            atom4 = self.atoms[atom4]
        vector12 = atom2.coordinates - atom1.coordinates
        vector23 = atom3.coordinates - atom2.coordinates
        vector34 = atom4.coordinates - atom3.coordinates
        distance12 = LA.norm(vector12)
        distance23 = LA.norm(vector23)
        distance34 = LA.norm(vector34)
        if incell == True:
            vector12 = self.incell3d(vector12, self.cell)
            vector23 = self.incell3d(vector23, self.cell)
            vector34 = self.incell3d(vector34, self.cell)
        inner123 = np.dot(-vector12, vector23)
        inner234 = np.dot(-vector23, vector34)
        angle123 = np.arccos(inner123 / (distance12 * distance23))
        angle234 = np.arccos(inner234 / (distance23 * distance34))
        evector12 = vector12 / LA.norm(vector12)
        evector23 = vector23 / LA.norm(vector23)
        evector34 = vector34 / LA.norm(vector34)
        cross1 = np.cross(evector12, evector23)
        cross2 = np.cross(evector23, evector34)
        inner = np.dot(cross1, cross2)
        dihedral = np.arccos(inner / (np.sin(angle123) * np.sin(angle234)))
        return dihedral / (np.pi) * 180

    def incell1d(self, x, px):
        return math.copysign(( abs(x) - int((abs(x) + 0.5 * px) / px) * px), x)

    def incell3d(self, x, px):
        return np.array([self.incell1d(x[0], px[0]), \
                         self.incell1d(x[1], px[1]), \
                         self.incell1d(x[2], px[2])])

    def molecular_detection(self):
        """
        Using the bonds to classify the atoms into groups of moleculars.
        """
        if len(self.bonds) == 0:
            self.generate_bonds()
        moleculars = [[atom.index] for atom in self.atoms]
        for bond in self.bonds:
            atomindex1 = bond[0]
            atomindex2 = bond[1]
            for molecularindex in range(len(moleculars)):
                if atomindex1 in moleculars[molecularindex]:
                    atom1_in_molecularindex = molecularindex
                if atomindex2 in moleculars[molecularindex]:
                    atom2_in_molecularindex = molecularindex
            if atom1_in_molecularindex != atom2_in_molecularindex:
                moleculars[atom1_in_molecularindex].extend(\
                    moleculars[atom2_in_molecularindex])
                del moleculars[atom2_in_molecularindex]
        self.moleculars = moleculars
        return self.moleculars

    def calculate_multidistances(self, atoms1, atoms2):
        """
        calculate multidistances input two group of atoms.
        """
        distances = []
        for atom1 in atoms1:
            for atom2 in atoms2:
                if isinstance(atom1, int):
                    atom1 = self.atoms[atom1]
                if isinstance(atom2, int):
                    atom2 = self.atoms[atom2]
                distance = self.calculate_length(atom1, atom2, True)
                distances.append(distance)
        return distances
        pass

    def add_ion_drude(self, changed_molecular_name, change_molecular_name_to, atom_name, shell_name):
        n_molecular = 0
        for molecular_name in self.molecular_names:
            n_molecular += 1
            if changed_molecular_name == molecular_name:
                ionatom = self.atoms[(self.moleculars[n_molecular-1][0])]
                ionatom.species = atom_name
                self.moleculars[n_molecular-1].append(len(self.atoms))
                self.atoms.append(atom(len(self.atoms), shell_name, ionatom.coordinates))
                self.molecular_names[n_molecular-1] = change_molecular_name_to
        return True

    def change_spc_to_swm4_ndp(self):
        for n in range(len(self.moleculars)):
            if self.molecular_names[n] == "SOL  ":
                ow_atom_index = self.moleculars[n][0]
                hw1_atom_index = self.moleculars[n][1]
                hw2_atom_index = self.moleculars[n][2]
                ow_atom = self.atoms[ow_atom_index]
                hw1_atom = self.atoms[hw1_atom_index]
                hw2_atom = self.atoms[hw2_atom_index]
                mw_vector = self.incell3d(hw1_atom.coordinates - ow_atom.coordinates, self.cell) + self.incell3d(hw2_atom.coordinates - ow_atom.coordinates, self.cell)
                mw_vector0 = mw_vector / LA.norm(mw_vector)
                mw_coordinates = ow_atom.coordinates + mw_vector0 * 0.024034
                mw_atom = atom(len(self.atoms), "MW", mw_coordinates)
                self.atoms.append(mw_atom)
                od_atom = atom(len(self.atoms), "OD", ow_atom.coordinates)
                self.atoms.append(od_atom)
                self.moleculars[n].append(mw_atom.index)
                self.moleculars[n].append(od_atom.index)
        return True

####TEST
#f = file("NaH2O.xyz")
#s = mdsystem([],[],[22.1884, 22.1884, 22.1884])
#s.xyzinput(f)

#####TEST
#f = file("1.gro")
#s = mdsystem([],[],[])
#s.groinput(f)
#f.close()
#f = file("1.gro")
