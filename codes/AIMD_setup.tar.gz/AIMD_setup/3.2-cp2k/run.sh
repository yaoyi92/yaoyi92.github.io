ln -s ../2.1-gromacs/eq.xyz .
/usr/mpi/intel/mvapich2-1.7/bin/mpiexec -n 12 ~/software/cp2k/cp2k_3.0_w_libxc_3.x.x/cp2k/cp2k/exe/local_libxc_wscan/cp2k.popt water55.inp > water55.out
