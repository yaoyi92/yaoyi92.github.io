head -n 167 eq.xyz | tail -n 165 > coord
sed 's/CELL_X_YY/22.331269952/' water_template.j > water_tmp.j
sed 's/NATOMS_YY/165/' water_tmp.j >  water_tmp2.j
sed "/COORD_YY/ r coord" water_tmp2.j > water_tmp3.j
sed "s/COORD_YY/ /" water_tmp3.j > water.j
rm water_tmp.j water_tmp2.j water_tmp3.j
