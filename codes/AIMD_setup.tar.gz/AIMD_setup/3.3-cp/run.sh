ln -s ../2.1-gromacs/eq.xyz .
bash generate_input.sh
bash water.j
