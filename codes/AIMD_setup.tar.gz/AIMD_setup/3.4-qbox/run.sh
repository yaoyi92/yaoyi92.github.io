ln -s ../2.1-gromacs/eq.xyz
python convert_xyz_to_xml.py > test.coord
cat test.coord run.head > test.i
bsub < run.lsf
