from mdsystem import *
f = file("eq.xyz")
s = mdsystem(cell = [11.8172, 11.8172, 11.8172])
s.xyzinput(f)
s.generate_bonds(cutoff = 1.2)
s.molecular_detection()
for i in range(len(s.moleculars)):
    s.molecular_names.append("SOL")

AtoBohr = 1.8897259886
print "set cell " , s.cell[0] * AtoBohr, 0, 0, \
                    0, s.cell[1] * AtoBohr, 0, \
                    0, 0, s.cell[2] * AtoBohr
print "species oxygen O_HSCV_PBE-1.0.xml"
print "species hydrogen H_HSCV_PBE-1.0.xml"

nO = 0
nH = 0
for atom in s:
    if atom.species == "O":
        nO += 1
        xyz = atom.coordinates * AtoBohr
        print "atom ", "O%d" %nO, "oxygen",  xyz[0], xyz[1], xyz[2]
    if atom.species == "H":
        nH += 1
        xyz = atom.coordinates * AtoBohr
        print "atom ", "H%d" %nH, "hydrogen",  xyz[0], xyz[1], xyz[2]


