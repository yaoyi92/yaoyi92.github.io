#####
LMP=~/software/lammps/lammps-26Nov14/bin/lmp_killdevil
VMD=vmd
#####
ln -s ../1.2-initial_structures_lammps/water55.data
ln -s ../1.2-initial_structures_lammps/water55.psf
$LMP -in in.spcf > out.spcf
# bsub < lammps.bsub
vmd -dispdev none -e take_last_snapshot.vmd
