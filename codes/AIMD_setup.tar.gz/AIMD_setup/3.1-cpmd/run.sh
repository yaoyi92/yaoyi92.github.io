HOMEDIR=`pwd`
ln -s ../../2.1-gromacs/eq.xyz COORD/
cd COORD
python cpmd_initial_structures.py eq.xyz
cd $HOMEDIR
#### wfopt
cat INPUT/1-wfopt.head COORD/coord > RUN/1-wfopt.inp
mkdir RUN/1-wfopt
cp Files/run_wfopt.sh RUN/1-wfopt/run.sh
cd RUN/1-wfopt
bash run.sh
cd $HOMEDIR
#### run
cat INPUT/2-run.head COORD/coord > RUN/2-run.inp
mkdir RUN/2-run
cp Files/LATEST RUN/2-run/
cp Files/run_run.sh RUN/2-run/run.sh
cd RUN/2-run
bash run.sh
cd $HOMEDIR
