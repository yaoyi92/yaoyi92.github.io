from sys import argv
from mdsystem import *
f = file(argv[1])
s = mdsystem([],[],[])
s.xyzinput(f)

atom_number = {}
atom_xyz = {}
for atom in s:
    if atom.species in atom_number:
        atom_number[atom.species] += 1
        atom_xyz[atom.species].append(atom.coordinates)
    else:
        atom_number[atom.species] = 1
        atom_xyz[atom.species] = [atom.coordinates]

f = open("coord" , 'w')
f.write( "&ATOMS\n")
f.write( "\n")
f.write( "ISOTOPES\n")
f.write( "16.01\n")
f.write( "1.008\n")
f.write( "\n")
f.write( "*O_MT_PBE.psp KLEINMAN-BYLANDER\n")
f.write( " LMAX=P LOC=P\n")
f.write( str(atom_number["O"])+"\n")
for coord in atom_xyz["O"]:
    f.write( "%f %f %f\n" % ( coord[0], coord[1], coord[2] ))
f.write( "\n")
f.write(  "*H_MT_PBE.psp KLEINMAN-BYLANDER\n")
f.write(  " LMAX=S LOC=S\n")
f.write( str(atom_number["H"])+"\n")
for coord in atom_xyz["H"]:
    f.write( "%f %f %f\n" % ( coord[0], coord[1], coord[2] ))
f.write("\n")
f.write("\n")
f.write( "&END\n")
f.close()
