mpiexec -n 12 /nas02/home/y/i/yiy/software/cpmd/CPMD_v4.1_scan/bin/cpmd.x ../1-wfopt.inp ../../Files/ >> 1-wfopt.out 2>&1
