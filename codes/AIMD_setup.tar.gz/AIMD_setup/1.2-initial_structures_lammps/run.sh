#### modify this
PACKMOL=~/software/packmol/packmol/packmol
VMD=vmd
####

$PACKMOL < water55_packmol.in > water55_packmol.out
$VMD -dispdev none -e convert.vmd
